# facebook-phishing
Mobile Facebook Phishing Page

Usage:
Upload HTML/CSS/PHP to your Webhost

Send html link to your target

Output will be written to "credentials.txt" in your Webhost.
